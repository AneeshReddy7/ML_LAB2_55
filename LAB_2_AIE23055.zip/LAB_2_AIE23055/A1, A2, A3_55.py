import numpy as np
import pandas as pd
from numpy import linalg

file_path = "C:\Users\arceu\Downloads\Lab Session Data.xlsx"
purchase_data = pd.read_excel(file_path, sheet_name="Purchase data")

input_features = purchase_data[["Candies (#)", "Mangoes (Kg)", "Milk Packets (#)"]].values
payment_values = purchase_data[["Payment (Rs)"]].values

input_shape = input_features.shape
num_input_features = input_features.shape[1]
matrix_rank = linalg.matrix_rank(input_features)
pseudo_inverse = linalg.pinv(input_features)
coefficients = np.dot(pseudo_inverse, payment_values)

print(f"Input Matrix Shape: {input_shape}")
print(f"Number of Input Features: {num_input_features}")
print(f"Matrix Rank: {matrix_rank}")
print(f"Calculated Coefficients: {coefficients}")

purchase_data["Customer Category"] = np.where(purchase_data["Payment (Rs)"] > 200, "RICH", "POOR")
print("\nCustomer Categories:")
print(purchase_data[["Customer", "Customer Category"]])
