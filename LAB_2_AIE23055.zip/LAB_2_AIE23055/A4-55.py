import statistics
import matplotlib.pyplot as plt
import pandas as pd

file_path = "C:\Users\arceu\Downloads\Lab Session Data.xlsx"
stock_data = pd.read_excel(file_path, sheet_name="IRCTC Stock Price")

stock_prices = stock_data.iloc[:, 3]
average_price = statistics.mean(stock_prices)
price_variance = statistics.variance(stock_prices)

wednesday_prices = stock_data[stock_data.iloc[:, 1] == "Wednesday"].iloc[:, 3]
average_wednesday_price = statistics.mean(wednesday_prices) if not wednesday_prices.empty else None

april_prices = stock_data[pd.to_datetime(stock_data.iloc[:, 0]).dt.month == 4].iloc[:, 3]
average_april_price = statistics.mean(april_prices) if not april_prices.empty else None

price_changes = stock_data.iloc[:, 8]
loss_probability = sum(price_changes < 0) / len(price_changes)
wednesday_profit_probability = sum((price_changes > 0) & (stock_data.iloc[:, 1] == "Wednesday")) / sum(stock_data.iloc[:, 1] == "Wednesday") if sum(stock_data.iloc[:, 1] == "Wednesday") > 0 else None
conditional_probability = wednesday_profit_probability / (sum(stock_data.iloc[:, 1] == "Wednesday") / len(stock_data)) if wednesday_profit_probability else None

plt.scatter(stock_data.iloc[:, 1], price_changes)
plt.xlabel("Day")
plt.ylabel("Change Percentage")
plt.title("Change Percentage vs Day")
plt.show()
