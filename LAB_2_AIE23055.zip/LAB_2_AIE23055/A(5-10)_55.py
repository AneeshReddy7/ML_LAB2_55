from sklearn.preprocessing import MinMaxScaler
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

file_path = "C:\Users\arceu\Downloads\Lab Session Data.xlsx"
thyroid_data = pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

numeric_columns = thyroid_data.select_dtypes(include=[np.number]).columns
categorical_columns = thyroid_data.select_dtypes(exclude=[np.number]).columns

print(thyroid_data.dtypes)
print(thyroid_data.describe())

thyroid_data[numeric_columns] = thyroid_data[numeric_columns].apply(
    lambda x: x.fillna(x.median() if ((x - x.mean()).abs() > 3 * x.std()).sum() > 0 else x.mean())
)
thyroid_data[categorical_columns] = thyroid_data[categorical_columns].apply(lambda x: x.fillna(x.mode()[0]))

print(thyroid_data.isnull().sum())

scaler = MinMaxScaler()
thyroid_data[numeric_columns] = scaler.fit_transform(thyroid_data[numeric_columns])

print(thyroid_data.head())

vec1 = thyroid_data.iloc[0, :].astype(bool)
vec2 = thyroid_data.iloc[1, :].astype(bool)

f11 = sum(vec1 & vec2)
f00 = sum(~vec1 & ~vec2)
f01 = sum(~vec1 & vec2)
f10 = sum(vec1 & ~vec2)

jaccard_similarity = f11 / (f01 + f10 + f11)
smc = (f11 + f00) / (f00 + f01 + f10 + f11)

print("Jaccard Similarity:", jaccard_similarity)
print("Simple Matching Coefficient:", smc)

vec1_full = thyroid_data.loc[0, numeric_columns].values.astype(np.float64)
vec2_full = thyroid_data.loc[1, numeric_columns].values.astype(np.float64)

cosine_similarity = np.dot(vec1_full, vec2_full) / (np.linalg.norm(vec1_full) * np.linalg.norm(vec2_full))
print("Cosine Similarity:", cosine_similarity)

similarity_matrix = np.zeros((20, 20))
for i in range(20):
    for j in range(20):
        v1 = thyroid_data.iloc[i, :].astype(bool)
        v2 = thyroid_data.iloc[j, :].astype(bool)
        f11 = sum(v1 & v2)
        f00 = sum(~v1 & ~v2)
        f01 = sum(~v1 & v2)
        f10 = sum(v1 & ~v2)
        jaccard_similarity = f11 / (f01 + f10 + f11)
        smc = (f11 + f00) / (f00 + f01 + f10 + f11)
        cosine_similarity = np.dot(thyroid_data.loc[i, numeric_columns].values.astype(np.float64), thyroid_data.loc[j, numeric_columns].values.astype(np.float64)) / \
                            (np.linalg.norm(thyroid_data.loc[i, numeric_columns].values.astype(np.float64)) * np.linalg.norm(thyroid_data.loc[j, numeric_columns].values.astype(np.float64)))
        similarity_matrix[i, j] = (jaccard_similarity + smc + cosine_similarity) / 3

plt.figure(figsize=(12, 8))
sns.heatmap(similarity_matrix, annot=True, cmap='coolwarm', fmt='.2f', cbar_kws={'label': 'Similarity'},
            xticklabels=range(1, 21), yticklabels=range(1, 21), linewidths=0.5)

plt.title('Similarity Matrix of Thyroid Data', fontsize=16)
plt.xlabel('Sample Index', fontsize=14)
plt.ylabel('Sample Index', fontsize=14)

plt.tight_layout()
plt.show()
